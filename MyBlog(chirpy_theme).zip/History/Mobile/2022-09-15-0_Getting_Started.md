---
title: '[Android App Pentesting] - Getting Started'
author: A1mH1gh
date: 2022-09-15 00:00:00 +0800
categories: [Mobile App Pentesting]
tags: [Android Pentesting]
math: true
mermaid: true
---
내가 학습한 Mobile App Pentesting 기술을 문서화하기 위해 이 블로그를 쓰게되었다

Pentesting Methology를 학습할 수 있는 소스는 Youtube, OWASP, Blog 등 무척 다양하였다. 그리고 그동안 학습의 결과로 크게 9가지 범주로 이해할 수 있었다.

- Malicious Behavior Detection
- Insecure Data Storage
- Insecure Commumication
- Insecure Authentication & Authorization
- Insecure Web View
- Code Level Issue
- Runtime Level Issue
- Weak Crypto
- ETC

앞으로 각 항목에서 발생할 수 있는 보안위협 및 취약점을 실습과 함께 적을 생각이다